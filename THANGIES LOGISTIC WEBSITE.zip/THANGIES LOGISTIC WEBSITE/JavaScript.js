document.addEventListener('DOMContentLoaded', function () {
    const gallery = document.querySelector('.product-gallery');
    const lightbox = document.getElementById('lightbox');
    const lightboxImage = document.querySelector('.lightbox-image');
    const closeBtn = document.querySelector('.close');
  
    gallery.addEventListener('click', function (event) {
      if (event.target.classList.contains('product-image')) {
        const imageUrl = event.target.src;
        lightboxImage.src = imageUrl;
        lightbox.style.display = 'block';
      }
    });
  
    closeBtn.addEventListener('click', function () {
      lightbox.style.display = 'none';
    });
  });